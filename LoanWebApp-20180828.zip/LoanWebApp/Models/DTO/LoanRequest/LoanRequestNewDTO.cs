﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LoanWebApp.Models.DTO.LoanRequest
{
    public class LoanRequestNewDTO: LoanRequestBaseDTO
    {
    }
}